> **CURRENT STATUS:** 30 RLS invitation was claimed via a new passkey, and @devil registration and zero-public-funding checks are independently verified. Outgoing private spend is still pending. Read [the current authoritative evidence register](research/CURRENT_VERIFICATION_REGISTER.md) before relying on older checkpoints.

# Rayls Quest 3 — The First-Gas Question

**Status on 21 November 2026:** independent controlled public-chain evidence and a fee-revenue pilot are verified. The private invitation claim/spend arm remains unfinished. **Do not submit this as the completed Quest.**

The full study ledger, current public-chain evidence, caveats, and next experiment gates are in [research/STATUS_2026-11-21.md](research/STATUS_2026-11-21.md). The preregistered protocol and dated amendments (including failures and the change of wallet operator) are in [research/PREREGISTRATION.md](research/PREREGISTRATION.md).

## Verified evidence at a glance
- Existing `@god` burner completed a **40 RLS** public shield transaction at **block 24,738,801**, with exact public relayer fee **3.50727828 RLS**, and a public encrypted-note commitment. The 40 RLS shielding principal and fee were independently reconciled to the fixed-block ERC-20 balance change.
- Link: https://testnet-explorer.rayls.com/tx/0x98bcb6f47b12400cb89284c215cc52373d38f8af30f855b9a0394c2923fa653a
- A relayer-to-reported-treasury transfer **0.45747108 RLS** followed three blocks later, exactly **15% of the 3.04980720 RLS implied base fee**. Link: https://testnet-explorer.rayls.com/tx/0x0f541a2275c4fcce2e43ba3219d37503fd38032932e0b94f9973f4cbce62233c
- An exploratory, nonrandom sample had **18/18 exact paid-fee-to-treasury matches**, with 3–9-block delays, and two zero-fee controls. This is a sample of public testnet transactions, not a universal network guarantee.
- Clean Hub receiver baseline: zero public RLS/USDr, zero nonce, no public transfers or registration at block **24,740,175**.
- Dev (separate research account): 250 RLS public faucet funded and a registration fee of 7.1930016 RLS independently verified.

## Reproduce offline and live
Requires Node 22+ and Python 3 with requests, plus a reachable public RPC for live checks.

```bash
cd experiments/browser && npm ci && cd ../..
node qa/verify_god_shield_offline.mjs
node qa/tamper_god_shield.mjs
node qa/verify_god_shield.mjs
python3 qa/verify_treasury_controls.py
python3 qa/verify_treasury_controls.py --tamper-tests
python3 research/reconcile_fee_treasury_controls.py
node research/audit_hub_preinvite.mjs
```

The release checkpoint includes public-chain addresses, transactions, contract-interface ABIs, snapshots, scripts and integrity hashes only. It excludes all private wallet keys, passkeys, invitation secrets, private note credentials and browser profile data.

## Scientific boundaries
`CONTROLLED_PUBLIC_CHAIN_RECONSTRUCTED` is not the same as `OWNER_WALLET_OBSERVED`. Public RPC proves the deposit, fee and note commitment, **not** that a particular private note is still spendable. The reported treasury address comes from the live relayer's API, not independently verified corporate identity. Publication of the final article and website is held until the invite, claim and private-spend experiments pass their own independent checks.

## Live sources
- https://docs.rayls.com/docs/enygma-public
- https://docs.rayls.com/docs/how-enygma-public-works
- https://docs.rayls.com/docs/enygma-public-who-sees-what
- https://docs.rayls.com/docs/try-enygma-public-on-testnet
- https://enygma-testnet.rayls.com/
- https://testnet-rpc.rayls.com/
- https://testnet-explorer.rayls.com/
- https://github.com/raylsnetwork/Enygma

The Quest website, three videos and final X article will be constructed from finished case evidence, after all trial controls pass.

## Independent 30 RLS invitation transaction (new checkpoint)
The user-controlled `@god` wallet also completed a **30 RLS private invitation**, whose public proof is a mined direct `SharedVault.transferV2` transaction, not a public token movement:
https://testnet-explorer.rayls.com/tx/0x6bedfee2032c1e1001c3dd5563df84d662cf965e0c7e3f301751a9b458d3c0ab

At block 24,744,028, the receipt recorded one nullifier, three new commitments and three encrypted notes. The 30 RLS and approx. 4.42 RLS fee are **wallet UI observations**, not plaintext values revealed by public RPC. The owner's public RLS balance remained unchanged. Live verification, frozen offline check and **19/19 tamper cases passed**.

The one-time bearer invite URL was exposed in a chat. It is intentionally never included in the research files. A claim or spend is **not yet proven**, and this checkpoint is **not the final Quest submission**.

Run:
```bash
node qa/verify_god_invite.mjs
node qa/verify_god_invite_offline.mjs
node qa/tamper_god_invite.mjs
```

### Pruned historical state after the shield
The original archived eth_call eventually failed because the live RPC pruned block 24,738,801. A separate live public event-reconstruction checker recovers the same exact accounting from current balances plus all later RLS Transfer logs: `python3 qa/verify_god_shield_postprune.py`. The original failure report is preserved.
