# Rayls Quest 3 — seven original research figures (frozen source bytes)

All seven original scientific article figures exactly match the public research repository, 1600×900 PNGs, same clean Rayls lime/violet dark visual style as the prior project.

F01: Actual milestones; place after public control baseline.
F02: Public Shield versus encrypted-note transfer; place after 40 RLS shield / invitation.
F03: Zero-public-funding recipient checkpoint; place after @devil claim and registration.
F04: ORIGINAL COHORT fee trail with **3 selected private operation examples** (invitation/claim/first send). Fourth selected private send's payout is VERIFIED SEPARATELY from the 2nd-cohort receipt; it is not plotted here.
F05: ORIGINAL COHORT replay evidence with **3 pre-state successes and 6 at/after reverts**. The 2nd-cohort saved replay adds **1 success and 2 reverts** separately; F05 does not visualize those additions.
F06: Evidence classes and scientific scope.
F07: Two distinct funding routes and the common receiving wallet with cumulative 3 → 6 RLS. F07 is NOT a fee-trail chart.

Article narrative figure order: F01, F02, F03, F07, F04, F05, F06.
The ZIP is the original public, evidence-grounded PNG data; the source published release and scientific QA are separately available in the repo.
No separate 5:2 cover art is represented here.
Public source: https://github.com/Glimorr/enygma-first-gas-research/tree/main/figures
